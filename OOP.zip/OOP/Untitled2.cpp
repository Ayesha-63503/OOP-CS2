#include <iostream>
using namespace std;


double kmToMiles(double km) {
    return km * 0.621; 
}


void secondsToTime(int seconds) {
    int hours = seconds / 3600;
    int minutes = (seconds % 3600) / 60;
    seconds = seconds % 60;
    
    cout << hours << " hours " << minutes << " minutes " << seconds << " seconds" << endl;
}


double celsiusToFahrenheit(double celsius) {
    return (celsius * 9/5) + 32;
}

int main() {
    int choice;
    double km, celsius;
    int seconds;

    do {
        
        cout << "\nConversion Menu:" << endl;
        cout << "1. Kilometers to Miles" << endl;
        cout << "2. Seconds to Hours, Minutes, and Seconds" << endl;
        cout << "3. Celsius to Fahrenheit" << endl;
        cout << "4. Exit" << endl;

        cout << "Enter your choice (1-4): ";
        cin >> choice;

        switch(choice) {
            case 1:
                
                cout << "Enter distance in kilometers: ";
                cin >> km;
                cout << km << " km = " << kmToMiles(km) << " miles" << endl;
                break;

            case 2:
                
                cout << "Enter time in seconds: ";
                cin >> seconds;
                secondsToTime(seconds);
                break;

            case 3:
                
                cout << "Enter temperature in Celsius: ";
                cin >> celsius;
                cout << celsius << " °C = " << celsiusToFahrenheit(celsius) << " °F" << endl;
                break;

            case 4:
                
                cout << "Exiting the program." << endl;
                break;

            default:
                
                cout << "Invalid choice. Please select a valid option (1-4)." << endl;
        }
    } while (choice != 4);  

    return 0;
}
