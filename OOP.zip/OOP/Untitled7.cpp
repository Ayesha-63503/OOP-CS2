#include <iostream>
using namespace std;


struct Employee {
    int empID;
    string name;
    float basicPay;
    float allowance;
    float deduction;
    float totalSalary;
};


void inputEmployeeData(Employee &emp) {
    cout << "Enter Employee ID: ";
    cin >> emp.empID;
    cout << "Enter Employee Name: ";
    cin.ignore();  
    getline(cin, emp.name);
    
  
    emp.basicPay = 50000;  
    
    
    emp.totalSalary = emp.basicPay + emp.allowance - emp.deduction;
}


void displayEmployeeData(const Employee &emp) {
    cout << "\nEmployee ID: " << emp.empID << endl;
    cout << "Employee Name: " << emp.name << endl;
    cout << "Basic Pay: " << emp.basicPay << endl;
    cout << "Allowance: " << emp.allowance << endl;
    cout << "Deduction: " << emp.deduction << endl;
    cout << "Total Salary: " << emp.totalSalary << endl;
}


void findHighestSalary(Employee employees[], int numEmployees) {
    int highestSalaryIndex = 0;
    for (int i = 1; i < numEmployees; i++) {
        if (employees[i].totalSalary > employees[highestSalaryIndex].totalSalary) {
            highestSalaryIndex = i;
        }
    }

    cout << "\nEmployee with the highest salary:\n";
    displayEmployeeData(employees[highestSalaryIndex]);
}

int main() {
    int numEmployees;

    
    cout << "Enter the number of employees: ";
    cin >> numEmployees;

    Employee employees[numEmployees];


    for (int i = 0; i < numEmployees; i++) {
        cout << "\nEnter data for Employee " << i + 1 << endl;
        inputEmployeeData(employees[i]);
    }

    
    for (int i = 0; i < numEmployees; i++) {
        cout << "\nDisplaying data for Employee " << i + 1 << endl;
        displayEmployeeData(employees[i]);
    }

    
    findHighestSalary(employees, numEmployees);

    return 0;
}
