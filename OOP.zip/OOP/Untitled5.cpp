#include <iostream>
using namespace std;


float calculateAllowance(float basicPay, float allowancePercentage) {
    return (basicPay * allowancePercentage) / 100;
}


float calculateDeduction(float basicPay, float deductionPercentage) {
    return (basicPay * deductionPercentage) / 100;
}


float calculateTotalSalary(float basicPay, float allowance, float deduction) {
    return basicPay + allowance - deduction;
}

int main() {
    float basicPay, allowancePercentage, deductionPercentage;

   
    cout << "Enter the basic pay: ";
    cin >> basicPay;

    cout << "Enter the allowance percentage: ";
    cin >> allowancePercentage;

    cout << "Enter the deduction percentage: ";
    cin >> deductionPercentage;

    float allowance = calculateAllowance(basicPay, allowancePercentage);
    float deduction = calculateDeduction(basicPay, deductionPercentage);

    float totalSalary = calculateTotalSalary(basicPay, allowance, deduction);

   
    cout << "\nBasic Pay: " << basicPay << endl;
    cout << "Allowance: " << allowance << endl;
    cout << "Deduction: " << deduction << endl;
    cout << "Total Salary: " << totalSalary << endl;

    return 0;
}
